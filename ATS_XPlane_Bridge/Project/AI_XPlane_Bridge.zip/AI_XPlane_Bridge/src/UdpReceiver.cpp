
#include "UdpReceiver.h"
#include "Logger.h"
#include <iostream>


UdpReceiver::UdpReceiver(int port) {
    WSADATA wsa{};
    int wsaRes = WSAStartup(MAKEWORD(2, 2), &wsa);
    if (wsaRes != 0) {
        XPLog("[AI_XPlane_Bridge] WSAStartup failed: %d", wsaRes);
        return;
    }

    mSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (mSock == INVALID_SOCKET) {
        XPLog("[AI_XPlane_Bridge] socket() failed: %d", WSAGetLastError());
        WSACleanup();
        return;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((u_short)port);

    if (bind(mSock, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        XPLog("[AI_XPlane_Bridge] bind() failed: %d", WSAGetLastError());
        closesocket(mSock);
        mSock = INVALID_SOCKET;
        WSACleanup();
        return;
    }

    // Non-blocking
    u_long nonBlocking = 1;
    if (ioctlsocket(mSock, FIONBIO, &nonBlocking) == SOCKET_ERROR) {
        XPLog("[AI_XPlane_Bridge] ioctlsocket(FIONBIO) failed: %d", WSAGetLastError());
    }

    XPLog("[AI_XPlane_Bridge] UDP listening on 0.0.0.0:%d", port);
}

UdpReceiver::~UdpReceiver() {
    if (mSock != INVALID_SOCKET) {
        closesocket(mSock);
        mSock = INVALID_SOCKET;
    }
    WSACleanup();
}

bool UdpReceiver::poll(char* outBuffer, int outBufferSize) {
    if (!outBuffer || outBufferSize <= 2) return false;
    if (mSock == INVALID_SOCKET) return false;

    sockaddr_in from{};
    int fromLen = sizeof(from);

    int r = recvfrom(mSock, outBuffer, outBufferSize - 1, 0, (sockaddr*)&from, &fromLen);
    if (r > 0) {
        outBuffer[r] = '\0';
        return true;
    }

    // Non-blocking: WSAEWOULDBLOCK is "no data yet"
    int err = WSAGetLastError();
    if (err == WSAEWOULDBLOCK) return false;

    // Other errors are real errors (but don’t spam each frame)
    return false;
}