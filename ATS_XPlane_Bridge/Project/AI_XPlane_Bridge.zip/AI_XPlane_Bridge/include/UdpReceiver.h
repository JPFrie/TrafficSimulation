
#pragma once
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>


class UdpReceiver {
public:
    explicit UdpReceiver(int port);
    ~UdpReceiver();

    // Returns true if a packet was received, and fills outBuffer with a null-terminated string.
    bool poll(char* outBuffer, int outBufferSize);

private:
    SOCKET mSock = INVALID_SOCKET;
};